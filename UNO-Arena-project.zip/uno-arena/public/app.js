'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const Engine = window.UnoEngine;
  const screens = ['home-screen', 'setup-screen', 'lobby-screen', 'game-screen'];
  const colors = ['red', 'yellow', 'green', 'blue'];
  const cardLabels = { skip: '⊘', reverse: '↻', draw2: '+2', wild: '✦', wild4: '+4' };
  const state = {
    mode: 'bots', setupMode: 'bots', onlineAction: 'create', localGame: null, onlineState: null,
    room: null, socket: null, difficulty: 'medium', pendingCardId: null,
    audioEnabled: false, music: null, musicContext: null, musicInterval: null, botTimer: null, toastTimer: null, lastTopId: null, resultShown: false,
  };

  function showScreen(id) {
    screens.forEach(screen => $(screen).classList.toggle('hidden', screen !== id));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function notify(message, type = 'info') {
    const node = document.createElement('div'); node.className = `notice notice-${type}`; node.textContent = message;
    $('notice-stack').appendChild(node); setTimeout(() => node.remove(), 3700);
  }
  function synthFallback(file, volume = 0.4) {
    const Context = window.AudioContext || window.webkitAudioContext;
    if (!Context) return;
    if (file === 'uno-callout.mp3' && window.speechSynthesis) {
      const line = new SpeechSynthesisUtterance('UNO !'); line.lang = 'fr-FR'; line.rate = 1.04; line.volume = Math.min(1, volume); window.speechSynthesis.cancel(); window.speechSynthesis.speak(line); return;
    }
    const ctx = state.musicContext || new Context(); state.musicContext = ctx;
    const now = ctx.currentTime;
    const patterns = {
      'card-click.mp3': [[740, .055, 'sine']],
      'card-play.mp3': [[210, .10, 'triangle'], [880, .15, 'sine']],
      'uno-callout.mp3': [[880, .12, 'triangle'], [1175, .18, 'sine']],
      'victory.mp3': [[523, .16, 'triangle'], [659, .16, 'triangle'], [784, .22, 'triangle'], [1046, .34, 'sine']],
      'defeat.mp3': [[392, .18, 'triangle'], [311, .22, 'triangle'], [247, .34, 'sine']],
    };
    const notes = patterns[file] || patterns['card-click.mp3'];
    let offset = 0;
    notes.forEach(([frequency, duration, wave]) => {
      const oscillator = ctx.createOscillator(); const gain = ctx.createGain();
      oscillator.type = wave; oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.0001, now + offset); gain.gain.exponentialRampToValueAtTime(Math.max(.001, volume * .17), now + offset + .012); gain.gain.exponentialRampToValueAtTime(.0001, now + offset + duration);
      oscillator.connect(gain); gain.connect(ctx.destination); oscillator.start(now + offset); oscillator.stop(now + offset + duration + .02); offset += duration * .72;
    });
  }
  function playSound(file, volume = 0.5) {
    if (!state.audioEnabled) return;
    const audio = new Audio(`/assets/audio/${file}`); audio.volume = volume;
    let fallbackUsed = false; const fallback = () => { if (fallbackUsed || !state.audioEnabled) return; fallbackUsed = true; synthFallback(file, volume); };
    audio.addEventListener('error', fallback, { once: true });
    audio.play().catch(fallback);
  }
  function startSynthMusic() {
    const Context = window.AudioContext || window.webkitAudioContext; if (!Context || state.musicInterval) return;
    const ctx = state.musicContext || new Context(); state.musicContext = ctx; ctx.resume().catch(() => {});
    const scale = [261.63, 329.63, 392, 493.88, 523.25, 659.25, 783.99]; let step = 0;
    const playNote = (frequency, duration, gainValue, type) => {
      const oscillator = ctx.createOscillator(); const gain = ctx.createGain(); const t = ctx.currentTime;
      oscillator.type = type; oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(.0001, t); gain.gain.exponentialRampToValueAtTime(gainValue, t + .04); gain.gain.exponentialRampToValueAtTime(.0001, t + duration);
      oscillator.connect(gain); gain.connect(ctx.destination); oscillator.start(t); oscillator.stop(t + duration + .02);
    };
    state.musicInterval = window.setInterval(() => { if (!state.audioEnabled) return; const note = scale[(step * 2 + (step % 3)) % scale.length]; playNote(note, .42, .018, 'triangle'); if (step % 4 === 0) playNote(note / 2, .7, .026, 'sine'); step++; }, 620);
  }
  function startMusic() {
    if (!state.audioEnabled) return;
    if (!state.music) { state.music = new Audio('/assets/audio/ambience.mp3'); state.music.loop = true; state.music.volume = 0.18; state.music.addEventListener('error', startSynthMusic, { once: true }); }
    state.music.play().catch(startSynthMusic);
  }
  function setAudio(enabled) {
    state.audioEnabled = enabled;
    $('sound-toggle').classList.toggle('sound-on', enabled);
    $('sound-icon').textContent = enabled ? '♫' : '♪';
    if (enabled) { startMusic(); playSound('card-click.mp3', 0.2); }
    else { if (state.music) state.music.pause(); if (state.musicInterval) { clearInterval(state.musicInterval); state.musicInterval = null; } }
  }
  function openSetup(mode) {
    state.setupMode = mode; state.mode = mode; state.onlineAction = 'create';
    const online = mode === 'online';
    $('setup-title').textContent = mode === 'bots' ? 'Prépare ton match.' : mode === 'local' ? 'Réunis tes joueurs.' : 'Monte ta table privée.';
    $('setup-subtitle').textContent = mode === 'bots' ? 'Choisis tes adversaires, règle la difficulté et lance la partie.' : mode === 'local' ? 'Configure une partie en hot-seat sur cet appareil.' : 'Crée un salon pour inviter tes amis, ou rejoins une partie avec un code.';
    $('difficulty-field').classList.toggle('hidden', mode !== 'bots');
    $('room-code-field').classList.toggle('hidden', true);
    $('online-mode-tabs').classList.toggle('hidden', !online);
    $('player-count').closest('.field').querySelector('span').textContent = online ? 'JOUEURS MAXIMUM' : 'NOMBRE DE JOUEURS';
    $('setup-submit').querySelector('span').textContent = online ? 'CRÉER LE SALON' : mode === 'bots' ? 'LANCER LA PARTIE' : 'OUVRIR LA TABLE';
    $('setup-note').innerHTML = online ? '<span>✦</span> Un code privé est généré. Partage-le avec tes amis pour jouer ensemble.' : mode === 'bots' ? '<span>✦</span> Les bots jouent automatiquement après chaque tour.' : '<span>✦</span> Les joueurs se passent l’appareil après chaque tour.';
    $('room-code').value = '';
    $('create-room-tab').classList.add('selected'); $('join-room-tab').classList.remove('selected');
    showScreen('setup-screen');
    setTimeout(() => $('player-name').focus(), 100);
  }
  function switchOnlineAction(action) {
    state.onlineAction = action;
    const joining = action === 'join';
    $('room-code-field').classList.toggle('hidden', !joining);
    $('player-count').closest('.field').classList.toggle('hidden', joining);
    $('create-room-tab').classList.toggle('selected', !joining);
    $('join-room-tab').classList.toggle('selected', joining);
    $('setup-submit').querySelector('span').textContent = joining ? 'REJOINDRE LA PARTIE' : 'CRÉER LE SALON';
    $('setup-note').innerHTML = joining ? '<span>✦</span> Saisis le code à 5 caractères envoyé par l’hôte.' : '<span>✦</span> Partage le code du salon avec tes amis.';
  }
  function makeLocalGame(mode) {
    clearTimeout(state.botTimer);
    const count = Number($('player-count').value) || 4;
    const name = $('player-name').value.trim() || 'Joueur';
    state.difficulty = $('difficulty').value;
    const players = [{ id: 'human-1', name, bot: false }];
    for (let i = 1; i < count; i++) players.push({ id: `seat-${i + 1}`, name: mode === 'bots' ? `Bot ${i}` : `Joueur ${i + 1}`, bot: mode === 'bots' });
    state.localGame = Engine.createGame(players);
    state.mode = mode; state.onlineState = null; state.room = null; state.resultShown = false;
    state.lastTopId = state.localGame.discard.at(-1)?.id;
    $('match-title').textContent = mode === 'bots' ? `SOLO · ${state.difficulty.toUpperCase()}` : 'PARTIE LOCALE';
    $('connection-label').textContent = mode === 'bots' ? 'Contre bots' : 'Mode local';
    showScreen('game-screen'); renderGame(); scheduleBot();
  }
  function getSocket() {
    if (!state.socket) {
      if (typeof window.io !== 'function') { notify('Le serveur temps réel est indisponible.', 'error'); return null; }
      state.socket = window.io({ transports: ['websocket', 'polling'] });
      state.socket.on('connect', () => { $('connection-label').textContent = 'En ligne'; });
      state.socket.on('disconnect', () => { $('connection-label').textContent = 'Déconnecté'; if (state.mode === 'online') notify('Connexion perdue. Recharge la page pour te reconnecter.', 'error'); });
      state.socket.on('room-created', ({ code }) => { state.room = { code }; $('room-code-display').textContent = code; showScreen('lobby-screen'); });
      state.socket.on('room-state', room => {
        state.room = { ...state.room, ...room };
        if (room.gameStarted) showScreen('game-screen');
        else { renderLobby(); showScreen('lobby-screen'); }
      });
      state.socket.on('state', incoming => {
        const prior = state.onlineState; state.onlineState = incoming;
        $('connection-label').textContent = 'En ligne'; $('match-title').textContent = 'SALON PRIVÉ · LIVE';
        if (prior && prior.top?.id !== incoming.top?.id) playSound('card-play.mp3', 0.55);
        if (incoming.winner && !prior?.winner) finishGame(incoming.winner === incoming.you, incoming.players.find(p => p.id === incoming.winner)?.name || 'Un joueur');
        renderGame();
      });
      state.socket.on('notice', n => notify(n.message, n.type || 'info'));
      state.socket.on('connect_error', () => notify('Connexion au serveur impossible. Réessaie.', 'error'));
    }
    return state.socket;
  }
  function createOnlineRoom(joining) {
    const socket = getSocket(); if (!socket) return;
    const name = $('player-name').value.trim() || 'Joueur';
    if (joining) {
      const code = $('room-code').value.trim().toUpperCase();
      if (!/^[A-Z0-9]{5}$/.test(code)) return notify('Le code doit contenir 5 caractères.', 'error');
      socket.emit('join-room', { name, code });
    } else socket.emit('create-room', { name, maxPlayers: Number($('player-count').value) || 6 });
  }
  function renderLobby() {
    if (!state.room?.players) return;
    $('room-code-display').textContent = state.room.code || '-----';
    const roster = $('lobby-roster'); roster.innerHTML = '';
    state.room.players.forEach((player, index) => {
      const row = document.createElement('div'); row.className = 'roster-player';
      const avatar = document.createElement('span'); avatar.className = `roster-avatar hue-${index % 4}`; avatar.textContent = player.name.slice(0, 1).toUpperCase();
      const info = document.createElement('div'); info.className = 'roster-info';
      const name = document.createElement('b'); name.textContent = player.name + (player.id === state.room.host ? ' · HÔTE' : '');
      const status = document.createElement('small'); status.textContent = 'PRÊT À JOUER'; info.append(name, status); row.append(avatar, info);
      const badge = document.createElement('span'); badge.className = 'roster-ready'; badge.textContent = '●'; row.appendChild(badge); roster.appendChild(row);
    });
    const empty = Math.max(0, state.room.maxPlayers - state.room.players.length);
    for (let i = 0; i < empty; i++) { const row = document.createElement('div'); row.className = 'roster-player roster-empty'; row.innerHTML = '<span class="roster-avatar">＋</span><div class="roster-info"><b>En attente…</b><small>PLACE DISPONIBLE</small></div>'; roster.appendChild(row); }
    $('lobby-status').textContent = `${state.room.players.length}/${state.room.maxPlayers} joueurs dans le salon`;
    $('start-online').disabled = !state.room.isHost || state.room.players.length < 2;
    $('start-online').querySelector('span').textContent = state.room.isHost ? 'LANCER LA PARTIE' : 'EN ATTENTE DE L’HÔTE';
  }
  function cardFace(card, small = false) {
    const label = cardLabels[card.value] || card.value;
    const accessible = card.value === 'draw2' ? 'Plus deux' : card.value === 'wild4' ? 'Joker plus quatre' : card.value === 'skip' ? 'Passe ton tour' : card.value === 'reverse' ? 'Inversion' : card.value === 'wild' ? 'Joker' : `Carte ${card.value}`;
    const element = document.createElement('div');
    element.className = `playing-card ${card.color}${small ? ' compact-card' : ''}`;
    element.setAttribute('aria-label', `${accessible}, ${card.color === 'wild' ? 'multicolore' : card.color}`);
    const top = document.createElement('span'); top.className = 'card-corner'; top.textContent = label;
    const center = document.createElement('b'); center.className = `card-center ${card.type === 'number' ? 'number-center' : 'symbol-center'}`; center.textContent = label;
    const bottom = document.createElement('span'); bottom.className = 'card-corner bottom-corner'; bottom.textContent = label;
    const ellipse = document.createElement('i'); ellipse.className = 'card-ellipse';
    if (card.color === 'wild') {
      const quadrant = document.createElement('span'); quadrant.className = 'wild-quadrants';
      ['red','yellow','green','blue'].forEach(c => { const span = document.createElement('i'); span.className = c; quadrant.appendChild(span); });
      ellipse.appendChild(quadrant);
    }
    element.append(top, ellipse, center, bottom);
    return element;
  }
  function cardBack() {
    const back = document.createElement('div'); back.className = 'card-back';
    const logo = document.createElement('span'); logo.textContent = 'UNO'; back.appendChild(logo); return back;
  }
  function getView() {
    if (state.mode === 'online') return state.onlineState ? { online: true, game: state.onlineState } : null;
    if (!state.localGame) return null;
    const local = state.localGame; const current = local.players[local.turn];
    const game = { ...local, top: Engine.topCard(local), deckCount: local.deck.length, turn: local.turn, players: local.players.map((p, index) => ({ ...p, count: p.hand.length, active: index === local.turn })) };
    return { online: false, game, you: current?.id, current, currentHand: current?.hand || [] };
  }
  function renderGame() {
    const view = getView(); if (!view) return;
    const game = view.game; const online = view.online;
    const me = online ? game.players.find(p => p.id === game.you) : game.players[game.turn];
    const active = online ? game.turn === game.you : !game.players[game.turn]?.bot;
    const currentName = online ? (game.players.find(p => p.id === game.turn)?.name || 'Joueur') : game.players[game.turn]?.name;
    $('turn-pill').textContent = active ? 'À TON TOUR' : `AU TOUR DE ${String(currentName).toUpperCase()}`;
    $('turn-pill').classList.toggle('is-waiting', !active);
    $('round-message').textContent = active ? (game.pendingDraw ? `PÉNALITÉ +${game.pendingDraw} · À TOI` : 'À TOI DE JOUER') : `AU TOUR DE ${currentName.toUpperCase()}`;
    $('deck-count').textContent = game.deckCount ?? game.deck?.length ?? 0;
    $('active-color').className = `active-color color-${game.chosenColor}`;
    $('active-color').querySelector('b').textContent = game.chosenColor.toUpperCase();
    $('active-color').querySelector('i').className = `color-orb ${game.chosenColor}`;
    $('penalty-banner').classList.toggle('hidden', !game.pendingDraw);
    $('penalty-banner').textContent = game.pendingDraw ? `+${game.pendingDraw} À PIOCHER · CUMULE OU PRENDS LA PÉNALITÉ` : '';
    $('draw-pile').disabled = !active || Boolean(game.drawnCardId);
    $('pass-button').classList.toggle('hidden', !(active && game.drawnCardId));
    $('pass-button').disabled = !active;
    const currentPlayer = online ? game.players.find(p => p.id === game.you) : game.players[game.turn];
    const hand = online ? (currentPlayer?.hand || []) : (currentPlayer?.bot ? [] : currentPlayer?.hand || []);
    $('hand-title').textContent = `${hand.length} CARTE${hand.length > 1 ? 'S' : ''}`;
    const unoTargetId = online ? game.you : game.unoPending;
    const unoTarget = online ? currentPlayer : game.players.find(p => p.id === unoTargetId);
    const canCallUno = Boolean(game.unoPending && unoTarget && unoTarget.hand?.length === 1 && !unoTarget.saidUno && (online ? game.unoPending === game.you : true));
    $('uno-button').classList.toggle('hidden', !canCallUno);
    $('uno-button').textContent = canCallUno && !online ? `UNO ! · ${unoTarget.name}` : 'UNO !';
    $('catch-uno-button').classList.toggle('hidden', !active || !(online ? game.canCatchUno : game.unoPending && game.unoPending !== game.players[game.turn]?.id));
    $('catch-uno-button').disabled = !active;
    $('hand-hint').textContent = !active ? 'La partie continue. Prépare ton prochain coup.' : currentPlayer?.bot ? `${currentPlayer.name} réfléchit à son prochain coup…` : game.pendingDraw ? 'Cumule un +2 / +4 pour renvoyer la pénalité, ou pioche les cartes.' : game.drawnCardId ? 'Joue la carte que tu viens de piocher, ou passe ton tour.' : 'Choisis une carte lumineuse pour la jouer. Ou pioche pour continuer.';

    const opponents = $('players-around'); opponents.innerHTML = '';
    game.players.filter(p => p.id !== (online ? game.you : game.players[game.turn]?.id)).forEach((player, index) => {
      const node = document.createElement('div'); node.className = `opponent-card opponent-${index % 5}${player.active ? ' opponent-active' : ''}`;
      const avatar = document.createElement('div'); avatar.className = `opponent-avatar hue-${index % 4}`; avatar.textContent = player.name.slice(0, 1).toUpperCase();
      const meta = document.createElement('div'); meta.className = 'opponent-meta';
      const name = document.createElement('b'); name.textContent = player.name;
      const count = document.createElement('span'); count.textContent = `${player.count} CARTES`;
      meta.append(name, count); node.append(avatar, meta);
      const backs = document.createElement('div'); backs.className = 'opponent-backs'; for (let i = 0; i < Math.min(player.count, 3); i++) backs.appendChild(cardBack()); node.appendChild(backs);
      if (player.count === 1) { const one = document.createElement('em'); one.textContent = player.saidUno ? 'UNO !' : '1 CARTE'; node.appendChild(one); }
      opponents.appendChild(node);
    });

    $('discard-pile').innerHTML = '';
    if (game.top) $('discard-pile').appendChild(cardFace(game.top));
    const playerHand = $('player-hand'); playerHand.innerHTML = '';
    hand.forEach((card, index) => {
      const playable = active && (!game.pendingDraw || ['draw2', 'wild4'].includes(card.value)) && (!game.drawnCardId || game.drawnCardId === card.id) && (online ? (card.color === 'wild' || card.color === game.chosenColor || card.value === game.top?.value) : Engine.isPlayable(game, card));
      const button = document.createElement('button'); button.type = 'button'; button.className = `hand-card${playable ? ' playable' : ''}${card.id === game.drawnCardId ? ' drawn-card' : ''}`; button.disabled = !playable;
      button.style.setProperty('--card-index', index); button.setAttribute('aria-label', `Jouer ${card.value === 'draw2' ? 'plus deux' : card.value === 'wild4' ? 'joker plus quatre' : card.value === 'wild' ? 'joker' : card.value} ${card.color}`);
      button.appendChild(cardFace(card)); button.addEventListener('click', () => selectCard(card.id)); playerHand.appendChild(button);
    });
    if (!hand.length && currentPlayer?.bot) { const wait = document.createElement('div'); wait.className = 'bot-thinking'; wait.textContent = 'BOT EN TRAIN DE JOUER…'; playerHand.appendChild(wait); }
    if (game.winner && !state.resultShown) {
      const winner = game.players.find(p => p.id === game.winner);
      finishGame(game.winner === (online ? game.you : game.players[0]?.id), winner?.name || 'Un joueur');
    }
  }
  function selectCard(cardId) {
    playSound('card-click.mp3', 0.25);
    const view = getView(); if (!view) return;
    const game = view.game; const hand = view.online ? game.players.find(p => p.id === game.you)?.hand : game.players[game.turn]?.hand;
    const card = hand?.find(c => c.id === cardId); if (!card) return;
    if (card.type === 'wild') { state.pendingCardId = cardId; $('color-modal').classList.remove('hidden'); return; }
    playSelected(cardId, null);
  }
  function playSelected(cardId, color) {
    if (state.mode === 'online') state.socket?.emit('play-card', { cardId, color });
    else {
      try { Engine.playCard(state.localGame, state.localGame.players[state.localGame.turn].id, cardId, color); playSound('card-play.mp3', 0.6); renderGame(); scheduleBot(); }
      catch (error) { notify(error.message, 'error'); }
    }
    $('color-modal').classList.add('hidden'); state.pendingCardId = null;
  }
  function draw() {
    const view = getView(); if (!view) return;
    if (view.online) state.socket?.emit('draw-card');
    else {
      try { Engine.drawCard(state.localGame, state.localGame.players[state.localGame.turn].id); playSound('card-play.mp3', 0.3); renderGame(); scheduleBot(); }
      catch (error) { notify(error.message, 'error'); }
    }
  }
  function passTurn() {
    const view = getView(); if (!view) return;
    if (view.online) state.socket?.emit('pass-turn');
    else { try { Engine.passTurn(state.localGame, state.localGame.players[state.localGame.turn].id); renderGame(); scheduleBot(); } catch (error) { notify(error.message, 'error'); } }
  }
  function announceUno() {
    const view = getView(); if (!view) return;
    playSound('uno-callout.mp3', 0.8);
    if (view.online) state.socket?.emit('call-uno');
    else { try { Engine.callUno(state.localGame, state.localGame.unoPending); renderGame(); } catch (error) { notify(error.message, 'error'); } }
  }
  function catchUno() {
    const view = getView(); if (!view) return;
    if (view.online) state.socket?.emit('catch-uno');
    else { try { Engine.catchUno(state.localGame, state.localGame.players[state.localGame.turn].id); playSound('card-play.mp3', 0.55); renderGame(); } catch (error) { notify(error.message, 'error'); } }
  }
  function scheduleBot() {
    clearTimeout(state.botTimer);
    if (state.mode !== 'bots' || !state.localGame || state.localGame.winner) return;
    const player = state.localGame.players[state.localGame.turn];
    if (!player?.bot) return;
    state.botTimer = setTimeout(() => {
      try { Engine.botTurn(state.localGame, state.difficulty); playSound('card-play.mp3', 0.48); renderGame(); scheduleBot(); }
      catch (error) { notify(error.message, 'error'); }
    }, 850 + Math.random() * 450);
  }
  function finishGame(won, winnerName) {
    if (state.resultShown) return;
    state.resultShown = true;
    playSound(won ? 'victory.mp3' : 'defeat.mp3', 0.75);
    $('result-kicker').textContent = won ? 'BIEN JOUÉ · MATCH TERMINÉ' : 'MATCH TERMINÉ';
    $('result-title').textContent = won ? 'VICTOIRE !' : 'FIN DE PARTIE';
    $('result-copy').textContent = won ? 'Tu as vidé ta main. La table est à toi.' : `${winnerName} remporte cette manche. On prend sa revanche ?`;
    $('result-modal').classList.remove('hidden');
  }
  function exitToHome() {
    clearTimeout(state.botTimer); $('result-modal').classList.add('hidden'); $('color-modal').classList.add('hidden');
    if (state.mode === 'online' && state.socket) state.socket.emit('leave-room');
    state.localGame = null; state.onlineState = null; state.room = null; state.resultShown = false;
    $('connection-label').textContent = 'Mode local'; showScreen('home-screen');
  }

  $('quick-play').addEventListener('click', () => openSetup('bots'));
  $('show-online').addEventListener('click', () => openSetup('online'));
  document.querySelectorAll('[data-pick]').forEach(button => button.addEventListener('click', () => openSetup(button.dataset.pick)));
  $('back-home').addEventListener('click', () => showScreen('home-screen'));
  $('create-room-tab').addEventListener('click', () => switchOnlineAction('create'));
  $('join-room-tab').addEventListener('click', () => switchOnlineAction('join'));
  $('setup-form').addEventListener('submit', event => {
    event.preventDefault();
    if (state.setupMode === 'online') createOnlineRoom(state.onlineAction === 'join');
    else makeLocalGame(state.setupMode);
  });
  $('room-code').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
  $('leave-lobby').addEventListener('click', exitToHome);
  $('copy-room-code').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.room?.code || $('room-code-display').textContent); notify('Code copié dans le presse-papiers.', 'success'); }
    catch { notify(`Code du salon : ${state.room?.code || $('room-code-display').textContent}`); }
  });
  $('start-online').addEventListener('click', () => state.socket?.emit('start-online'));
  $('draw-pile').addEventListener('click', draw);
  $('pass-button').addEventListener('click', passTurn);
  $('uno-button').addEventListener('click', announceUno);
  $('catch-uno-button').addEventListener('click', catchUno);
  document.querySelectorAll('[data-color]').forEach(button => button.addEventListener('click', () => playSelected(state.pendingCardId, button.dataset.color)));
  $('color-modal').addEventListener('click', event => { if (event.target === $('color-modal')) $('color-modal').classList.add('hidden'); });
  $('sound-toggle').addEventListener('click', () => setAudio(!state.audioEnabled));
  $('exit-game').addEventListener('click', exitToHome);
  $('restart-button').addEventListener('click', () => {
    if (state.mode === 'online') return notify('Quitte ce salon pour créer une nouvelle partie.', 'info');
    makeLocalGame(state.mode);
  });
  $('play-again').addEventListener('click', () => { $('result-modal').classList.add('hidden'); if (state.mode === 'online') exitToHome(); else makeLocalGame(state.mode); });
  $('result-home').addEventListener('click', exitToHome);
  $('profile-pill').addEventListener('click', () => { if (state.localGame) notify(`Joueur : ${state.localGame.players[0].name}`); else openSetup('bots'); });

  // Sound is enabled only after an explicit user action; browsers block autoplay by default.
  $('connection-label').textContent = 'Mode local';
})();
